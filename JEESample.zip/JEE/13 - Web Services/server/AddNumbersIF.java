package annotations.server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.soap.SOAPBinding;
import javax.jws.WebResult;
import javax.jws.WebParam;
import javax.jws.soap.SOAPBinding.ParameterStyle;

@WebService(targetNamespace = "http://www.stayahead.com", name="AddNumbers")
@SOAPBinding(style=SOAPBinding.Style.RPC, use=SOAPBinding.Use.LITERAL,
    parameterStyle = ParameterStyle.WRAPPED)
public interface AddNumbersIF {

    @WebMethod(operationName="add", action="urn:addNumbers")
    @WebResult(name="return")
    public int addNumbers(
        @WebParam(name="num1")int number1,
        @WebParam(name="num2")int number2) throws AddNumbersException;

}