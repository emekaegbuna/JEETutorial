public class DeptAccess extends HttpServlet {
    private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

    Department dept = new Department();
    Long departmentNr = (long)10;

    @PersistenceContext(unitName = "JEEWebPU")
    private EntityManager em;


    public void doGet(HttpServletRequest request, 
                      HttpServletResponse response) throws ServletException, IOException {response.setContentType(CONTENT_TYPE);

        List <Department> depts =
                em.createQuery("select d from Department d").getResultList();
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>HelloServlet</title></head>");
        out.println("<body>");
        out.println("<p>" + depts.toString() + "</p>");
        out.println("</body></html>");
        out.close();
    }
}