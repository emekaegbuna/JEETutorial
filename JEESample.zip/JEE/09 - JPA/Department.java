package model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "Department.findAll", query = "select o from Department o")
public class Department implements Serializable {
    @Id
    @Column(name="DEPARTMENT_NR", nullable = false)
    private Long departmentNr;
    @Column(nullable = false)
    private String location;
    @Column(nullable = false)
    private String name;

    public Department() {
    }

    public Long getDepartmentNr() {
        return departmentNr;
    }

    public void setDepartmentNr(Long departmentNr) {
        this.departmentNr = departmentNr;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

/*    public String toString() {
        return "" + getDepartmentNr() + " " + getName() + " " + getLocation();
    }*/
}
