package jeeweb;

public class Messages {
    private String message;

    public Messages(String msg) {
        message = msg;
    }

    public String getMessage(){
        return message;
    }
}
