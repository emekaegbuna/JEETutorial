package employee.model;

import java.sql.*;
import java.util.ArrayList;

class JEEDataClass {

    private static Connection createConnection() throws ClassNotFoundException, 
                                                        SQLException {
        String url = "jdbc:oracle:thin:@localhost:1521:sat";
        String driverName = "oracle.jdbc.OracleDriver";
        String user = "user1";
        String password = "user1";

        Class.forName(driverName);
        return DriverManager.getConnection(url, user, password);
    }

    private static void doClose(Connection con) {
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println("Problems closing connection.");
        }
    }

    private static void doClose(Statement state) {
        try {
            state.close();
        } catch (SQLException e) {
            System.out.println("Problems closing the statement.");
        }
    }

    private static void doClose(ResultSet rs) {
        try {
            rs.close();
        } catch (SQLException e) {
            System.out.println("Problems closing the resultset.");
        }
    }

    public static ArrayList <String> processData(String sql) throws ClassNotFoundException,
                                                        SQLException {
        Connection con = null;
        Statement stmt = null;
        ResultSet result = null;
        try {
            con = createConnection();
            stmt = con.createStatement();
            result = stmt.executeQuery(sql);

            //new for headings and ArrayList
            ArrayList <String> output = new ArrayList <String> ();
            StringBuffer heading = new StringBuffer("");
            StringBuffer rowText = new StringBuffer("");
            result = stmt.executeQuery(sql);
            ResultSetMetaData meta = result.getMetaData();
            for (int i=1; i <= meta.getColumnCount(); i++)
                heading.append(meta.getColumnName(i) + "\t") ;
            
            //begin the ArrayList with the headings
            output.add(heading + "\n");

            while (result.next()) {
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    if (meta.getColumnTypeName(i).equals("VARCHAR2")
                            || meta.getColumnTypeName(i).equals("CHAR")) {
                        rowText.append(result.getString(meta.getColumnName(i)));
                    }
                    if (meta.getColumnTypeName(i).equals("NUMBER")) {
                        rowText.append(result.getInt(meta.getColumnName(i)));
                    }
                    if (meta.getColumnTypeName(i).equals("DATE")) {
                        rowText.append(result.getDate(meta.getColumnName(i)));
                    }
                    rowText.append("\t");
                }
                rowText.append("\n");
                output.add(rowText.toString());
                rowText.delete(0, rowText.length());
            }
            return output;
        } finally {
            doClose(result);
            doClose(stmt);
            doClose(con);
        }
    }
} 
