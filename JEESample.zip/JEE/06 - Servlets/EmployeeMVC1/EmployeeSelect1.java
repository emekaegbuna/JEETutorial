package employee.web;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmployeeSelect extends HttpServlet {
    private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response) throws ServletException,
                                                            IOException {

        response.setContentType(CONTENT_TYPE);
        PrintWriter out = response.getWriter();
        out.println("Employee Listing by Department<br>");
        String d = request.getParameter("dept");
        out.println("You chose department " + d);

    }
}