package employee.web;

import employee.model.EmployeeModel;
import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmployeeSelect extends HttpServlet {
    private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response) throws ServletException,
                                                            IOException {

        response.setContentType(CONTENT_TYPE);

        String d = request.getParameter("dept");
        EmployeeModel em = new EmployeeModel();
        ArrayList <String> result = em.getEmployees(d);

        // Servlet version 2 code follows:
        response.setContentType(CONTENT_TYPE);
        PrintWriter out = response.getWriter();
        out.println("Employee Listing by Department<br>");
        out.println("You chose department " + d + "<br>");
        for (int i = 0; i < result.size(); i++)
            out.println(result.get(i) + "<br>");
        out.close();

    }
}
