package employee.model;

import java.sql.SQLException;
import java.util.ArrayList;

public class EmployeeModel {
    public ArrayList <String> getEmployees(String department) {

        ArrayList <String> data = new ArrayList <String> ();
        String query = "select * from employee where department_nr = "
                + department;
        try {
            data = JEEDataClass.processData(query);
        } catch (ClassNotFoundException e) {
            System.out.println("Problems with driver or obtaining 						connection. " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Problems with Statement or 									ResultSet. " + e.getMessage());
        }
        return(data);
    }
}