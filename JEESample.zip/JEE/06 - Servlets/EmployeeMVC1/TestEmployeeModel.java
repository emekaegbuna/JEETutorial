package employee.model;

import java.util.*;

public class TestEmployeeModel {
    public static void main(String[] args) {
        String department = "20";
        EmployeeModel em = new EmployeeModel();
        ArrayList <String> emps = em.getEmployees(department);
        for (String s : emps)
            System.out.println(s);
    }
}
