package jeeweb;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class HelloServlet2 extends HttpServlet {

        public void doGet(HttpServletRequest request,
                      HttpServletResponse response) throws ServletException,
                                                           IOException {
        String message = request.getParameter("message");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>HelloServlet</title></head>");
        out.println("<body>");
        out.println("<h1>Hello " + message + "<h1>");
        out.println("</body></html>");
        out.close();
    }
}
