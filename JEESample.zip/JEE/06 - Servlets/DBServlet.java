package examples;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import oracle.jdbc.OracleDriver;

public class DBServlet extends HttpServlet{
     Connection conn;
     private ServletConfig config;

    public void init(ServletConfig config) throws ServletException{
        this.config=config;
    }

    public void service (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession(true);
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<HTML><HEAD><TITLE>Customer List.</TITLE>");
        out.println("</HEAD>");
        out.println("<BODY bgColor=blanchedalmond text=#008000 topMargin=0>");
        out.println("<P align=center><FONT face=Helvetica><FONT color=fuchsia style=\"BACKGROUND-COLOR: white\"><BIG><BIG>List of Customers</BIG></BIG></FONT></P>");
        out.println("<P align=center>");
        out.println("<TABLE align=center border=1 cellPadding=1 cellSpacing=1 width=\"75%\">");
        out.println("<TR>");
        out.println("<TD>Name</TD>");
        out.println("<TD>Town</TD>");
        out.println("<TD>Credit Limit</TD></TR>");
        try{
        
            //Class.forName("oracle.jdbc.OracleDriver");
            DriverManager.registerDriver(new OracleDriver());
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:work","user1","user1");
            Statement stat = conn.createStatement();
            ResultSet result = stat.executeQuery("select surname,town,credit_limit from customer");
            
            while (result.next()){
                out.println();
                out.println("<TR>");
                out.println("<TD>" + result.getString(1) + "</TD>");
                out.println("<TD>" + result.getString(2) + "</TD>");
                out.println("<TD>" + result.getString(3) + "</TD>");
                out.println("</TR>");
            }
            
            result.close();
            stat.close();
            conn.close();
            
        } catch(Exception e){
            out.println(e.getMessage());
        }
        out.println("</TABLE></P>");
        out.println("<P>&nbsp;</P></FONT></BODY></HTML>");
    }   
}

