package jsfgreeting;

public class PersonBean {

   private String personName;

   public String getPersonName() {
      return personName;
   }

   public void setPersonName(String name) {
      personName = name;
   }
}
