package com.beans;

import java.sql.*;

public class JEEDataApplication {

    public static void main(String[] args) {
        try {
            String data = JEEDataClass.processData(
                    "Select * From Employee");
            System.out.println(data);
        } catch (ClassNotFoundException e) {
            System.out.println("Problems with driver or obtaining 						connection. " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Problems with Statement or 									ResultSet. " + e.getMessage());
        }
    }
}

