package com.beans;

import java.sql.*;

class JEEDataClass {

    private static Connection createConnection() throws
            ClassNotFoundException, SQLException {
        String url = "jdbc:oracle:thin:@localhost:1521:sat";
        String driverName = "oracle.jdbc.OracleDriver";
        String user = "user1";
        String password = "user1";

        Class.forName(driverName);
        return DriverManager.getConnection(url, user, password);
    }

    private static void doClose(Connection con) {
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println("Problems closing connection.");
        }
    }

    private static void doClose(Statement state) {
        try {
            state.close();
        } catch (SQLException e) {
            System.out.println("Problems closing the statement.");
        }
    }

    private static void doClose(ResultSet rs) {
        try {
            rs.close();
        } catch (SQLException e) {
            System.out.println("Problems closing the resultset.");
        }
    }

    public static String processData(String sql) throws ClassNotFoundException, SQLException {
        Connection con = null;
        Statement stmt = null;
        ResultSet result = null;
        try {
            con = createConnection();
            stmt = con.createStatement();
            result = stmt.executeQuery(sql);
            StringBuffer rowText = new StringBuffer("");
            //ResultSetMetaData meta = result.getMetaData();

            while (result.next()) {
                rowText.append(result.getString("SURNAME") + "\t");
                rowText.append(result.getInt("EMPLOYEE_NR") + "\t");
                rowText.append(result.getString("JOB") + "\t");
                rowText.append(result.getDouble("SALARY") + "\n");

            }
            /*while (result.next()) {
                for (int i=1; i <= meta.getColumnCount(); i++) {
                    if (meta.getColumnTypeName(i).equals("VARCHAR2")
                        || meta.getColumnTypeName(i).equals("CHAR"))
                        rowText.append(result.getString(meta.getColumnName(i)));
                    if (meta.getColumnTypeName(i).equals("NUMBER"))
                        rowText.append(result.getInt(meta.getColumnName(i)));
                    if (meta.getColumnTypeName(i).equals("DATE"))
                        rowText.append(result.getDate(meta.getColumnName(i)));
                    rowText.append("\t");
                }
                rowText.append("\n");
            }*/
            return rowText.toString();

        } finally {
            doClose(result);
            doClose(stmt);
            doClose(con);
        }
    }
}

