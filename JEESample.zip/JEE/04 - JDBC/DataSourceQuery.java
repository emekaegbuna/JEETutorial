package jee;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DataSourceQuery {
    public static void main(String[] args) {
        try {
            InitialContext ctx = new InitialContext();
            DataSource ds = (DataSource) ctx.lookup("data source name");
            Connection conn = ds.getConnection();
            Statement stat = conn.createStatement();
            ResultSet result = stat.executeQuery("select * from customer");
            while (result.next())
                System.out.println(result.getString("surname") + "\t" + 
                                   result.getString("town"));
            System.out.println(result.getFetchSize() + " rows retrieved");
            result.close();
            stat.close();
            conn.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
