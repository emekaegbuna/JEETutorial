package ejb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

@MessageDriven(mappedName = "jms/Topic", activationConfig = {
    @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"),
    @ActivationConfigProperty(propertyName = "subscriptionDurability", propertyValue = "Durable"),
    @ActivationConfigProperty(propertyName = "clientId", propertyValue = "MessageBeanBean"),
    @ActivationConfigProperty(propertyName = "subscriptionName", propertyValue = "MessageBeanBean")
})
public class MessageBeanBean implements MessageListener {

    public MessageBeanBean() {
    }

    public void onMessage(Message message) {
        MapMessage msg = null;
        try {

            msg = (MapMessage) message;
            System.out.println("—————————————-");
            System.out.println(msg.getString("lastname"));
            System.out.println(msg.getString("firstname"));
            System.out.println(msg.getString("id"));
            System.out.println("—————————————-");
        } catch (Exception e) {
        }

    }
}
