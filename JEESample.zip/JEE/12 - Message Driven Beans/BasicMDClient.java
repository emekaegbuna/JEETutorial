package jee;

public class BasicMDClient {
    public BasicMDClient() {
    }
}
