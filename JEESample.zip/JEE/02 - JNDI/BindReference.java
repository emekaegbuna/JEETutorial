package sat.jee;

import javax.naming.*;

import java.util.Hashtable;

public class BindReference {
    public static void main(String[] args) {
        try {
            String name = "boundname";
            Hashtable env = new Hashtable();
            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.fscontext.RefFSContextFactory");
            env.put(Context.PROVIDER_URL, "file://C:/labs");
            Context ctx = new InitialContext(env);

            // Bind a reference to a specified context.
            ctx.rebind(name, new Reference("sat.jee.BindTest"));

            Object obj = ctx.lookup(name);
            String nm = ((Reference)obj).getClassName();
            Class c = Class.forName(nm);
            BindTest instance = (BindTest)c.newInstance();
            System.out.println("\n\nClass Name: " + nm);
            System.out.println("\nField value: " + instance.getField());
            ctx.close();
        } catch (Exception ne) {
            ne.printStackTrace();
        }
    }
}

