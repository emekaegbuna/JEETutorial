package sat.jee;

import javax.naming.*;
import java.util.*;
import java.io.*;

public class ListBindings {
    public static void main(String[] args) {
        try {
            Hashtable env = new Hashtable();
            env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.fscontext.RefFSContextFactory");
            env.put(Context.PROVIDER_URL, "file://C:/labs");
            Context ctx = new InitialContext(env);
            NamingEnumeration name = ctx.listBindings("");
            while (name.hasMore()) {
                Binding binding = (Binding)name.next();
                System.out.println( binding.getName() + " " + binding.getObject());
            }
            File f = (File)ctx.lookup("DBServlet.java");
            System.out.println("DBServlet.java: " + f);
            System.out.println("The length of this file is " + f.length() + " bytes.");
        } catch(NamingException ne) {
            ne.printStackTrace();
        }
    } 
} 

