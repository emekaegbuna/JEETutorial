package sat.jee;

class BindTest {
    private int field = 50;

    public int getField() {
        return this.field;
    }
}
