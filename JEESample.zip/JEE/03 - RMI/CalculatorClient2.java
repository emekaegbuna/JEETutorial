package jeeapp;

import java.rmi.Naming;

public class CalculatorClient {
    public static void main(String[] args) {
        String url = "rmi://192.168.168.24/";
        try {
            Calculator c = (Calculator)Naming.lookup(url + "cal");
            System.out.println(c.sum(2.0, 3.5));
        } catch(Exception e) {
            System.out.println("Error: " + e);
        }
    }
}
