package jee;

import java.rmi.*;
import java.rmi.server.*;

public class CalculatorServer { 
    public static void main(java.lang.String[] args) { 
        try { 
            CalculatorImpl c = new CalculatorImpl();
            // Binds the name to be associated with the 
            //remote  object to the rmi registry running on the 	
            // server. If no IP address/port number supplied, 
            // this defaults to localhost/1099.
            Naming.rebind("cal", c);
        } catch(Exception e) { 
            System.out.println("Error: " + e);
        }
        // Although this class seems to finish, the 
        // CalculatorImpl is a separate thread keeping 
        // the program alive indefinitely, because it has a
        // remote reference in another VM � the registry 					// itself.
    }
}

