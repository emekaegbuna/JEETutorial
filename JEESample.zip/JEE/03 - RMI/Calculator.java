package jee;

import java.rmi.*;
 
public interface Calculator extends Remote {    
    public double sum(double x, double y) throws RemoteException;
}