package jee;

import java.rmi.*;
import java.rmi.server.*;

public class CalculatorImpl extends UnicastRemoteObject implements Calculator {	
    public CalculatorImpl() throws RemoteException { 
        System.out.println("CalculatorImpl: instantiated");
    }
  
    public double sum(double x, double y) throws RemoteException { 
        System.out.println("CalculatorImpl: adding " 
            + x + " and " + y + " giving " + (x+y));
        return x + y;
    }
}

