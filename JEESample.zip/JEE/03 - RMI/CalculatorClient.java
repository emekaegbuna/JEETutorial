package jee;

import java.rmi.*;
import java.rmi.server.*;

public class CalculatorClient { 
    public static void main(String[] args) { 
        String url = "rmi:///";
        // Note: when hooking to true remote server this 
        // should be "rmi://x/" where x is ip address or DNS
        try { 
            Calculator c = (Calculator)
            Naming.lookup(url + "cal");
            System.out.println( c.sum(2.0,3.5) );
        } catch(Exception e) 	{ 
            System.out.println("Error:" + e);
        }
    }
}

