package employee.web;

import employee.model.EmployeeModel;
import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmployeeSelect extends HttpServlet {
    private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response) throws ServletException,
                                                            IOException {

        response.setContentType(CONTENT_TYPE);

        String d = request.getParameter("dept");
        EmployeeModel em = new EmployeeModel();
        ArrayList <String> result = em.getEmployees(d);

        //Add an attribute to the request object called "employees"
        request.setAttribute("employees", result);
        //Instantiate a request dispatcher for the JSP
        RequestDispatcher view = request.getRequestDispatcher("result.jsp");
        //Use the request dispatcher to ask the container to start up the JSP
        //and pass it the request and response
        view.forward(request, response);
    }
}
