package jee;

public class OrderEntryException extends Exception {
}
