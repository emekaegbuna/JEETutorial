package jee;

import javax.ejb.*;
import javax.annotation.*;
import javax.transaction.*;

@Stateful
@TransactionManagement(TransactionManagementType.BEAN)
public class OrderEntryBean implements OrderEntry {
    @Resource
    UserTransaction ut;
    private double creditLimit;

    public double updateCredit(double v) {
        creditLimit = v;
        try {
            ut.begin();
            creditLimit = creditLimit * 1.1;
            ut.commit();

        } catch (Exception e) {
            try {
                ut.rollback();
                System.out.println("Failure");
            } catch (SystemException f) {
                System.out.println("Disaster");
            }
        }
        return creditLimit;
    }
}

