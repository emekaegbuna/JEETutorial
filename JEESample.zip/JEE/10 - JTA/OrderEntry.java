package jee;

import javax.ejb.Remote;

@Remote
public interface OrderEntry {
    public double updateCredit(double v);
}
