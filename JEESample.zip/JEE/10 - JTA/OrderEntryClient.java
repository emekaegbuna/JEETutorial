package jee;

import javax.naming.InitialContext;
import javax.naming.NamingException;

public class OrderEntryClient {

    public static void main(String[] args) throws NamingException {
        OrderEntry oe;
        
        InitialContext ic = new InitialContext();
        oe = (OrderEntry)ic.lookup("OrderEntryBean");
        oe.updateCredit(1000);
    }
}
