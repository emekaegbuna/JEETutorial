package jee;

import javax.ejb.Stateless;

@Stateless
public class HelloSBImpl implements HelloSB {
    public String sayHello(){
        return "Hello World";
    }
}
