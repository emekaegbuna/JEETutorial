package jee;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.naming.*;

public class HelloSBServlet extends HttpServlet {
    private static final String CONTENT_TYPE = "text/html; charset=windows-1252";
    private static HelloSB hello;

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try{
            InitialContext ic = new InitialContext();
            hello = (HelloSB) ic.lookup("HelloSBImpl");
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    public void doGet(HttpServletRequest request, 
                      HttpServletResponse response) throws ServletException, IOException {response.setContentType(CONTENT_TYPE);
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>HelloSBServlet</title></head>");
        out.println("<body>");
        out.println("<p>" + hello.sayHello() + "</p>");
        out.println("</body></html>");
        out.close();
    }
}
