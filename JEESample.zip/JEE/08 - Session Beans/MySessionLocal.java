/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mypackage;

import javax.ejb.Local;

/**
 *
 * @author Administrator
 */
@Local
public interface MySessionLocal {

    String sayHello(String name);
    
}
