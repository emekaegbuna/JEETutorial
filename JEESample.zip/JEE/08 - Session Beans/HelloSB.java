package jee;

import javax.ejb.Remote;

@Remote
public interface HelloSB {
    public String sayHello();
}
