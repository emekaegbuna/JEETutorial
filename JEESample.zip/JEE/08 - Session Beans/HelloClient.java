package jee;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class HelloClient {
    public static void main(String [] args) {
        try {
            final Context context = getInitialContext();
            HelloSB hello = (HelloSB)context.lookup("HelloSBImpl");
            String s = hello.sayHello();
            System.out.println(s);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static Context getInitialContext() throws NamingException {
        // Get InitialContext for Embedded OC4J
        // The embedded server must be running for lookups to succeed.
        return new InitialContext();
    }
}
