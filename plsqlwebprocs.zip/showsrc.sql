create or replace procedure showsrc
is
begin
header;
owa_util.showsource('home');
footer;
end showsrc;
/
